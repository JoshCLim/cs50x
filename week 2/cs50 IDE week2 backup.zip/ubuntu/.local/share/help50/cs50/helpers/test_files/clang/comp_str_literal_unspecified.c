int main(void) {
  int x = 0;
  if ("general" < "kenobi") {
    x++;
  }
}
