int main(void) {
  int i = 1;
  if (i < 23) && (i > 0) {

  }
}
