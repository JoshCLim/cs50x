#include <stdio.h>

int main(void) {
  if (1 == 1
    printf("hi\n");
}
