int main(void) {
  int x;
  x = 28 / 0;
}
