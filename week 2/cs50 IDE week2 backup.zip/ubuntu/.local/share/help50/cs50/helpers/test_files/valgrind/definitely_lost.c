#include <stdlib.h>

int main(void) {
  int *x = malloc(sizeof(int));
}
