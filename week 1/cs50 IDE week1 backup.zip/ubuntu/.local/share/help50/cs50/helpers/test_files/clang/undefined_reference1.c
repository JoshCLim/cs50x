int main(void) {
  int x = foo();
}
