int main(void) {
  int x = 1;
  switch (x) {
    case ("hello"): break;
  }
}
