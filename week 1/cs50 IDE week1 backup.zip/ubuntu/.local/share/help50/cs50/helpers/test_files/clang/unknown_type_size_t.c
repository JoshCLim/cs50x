size_t baz;
int main(void) {
}
