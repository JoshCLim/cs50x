square (int x) {
  x++;
}

int main(void);
