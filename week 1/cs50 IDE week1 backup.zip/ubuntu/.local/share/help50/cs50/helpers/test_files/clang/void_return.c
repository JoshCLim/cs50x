void f(void);

int main(void) {
  f();
}

void f(void) {
  return 0;
}
