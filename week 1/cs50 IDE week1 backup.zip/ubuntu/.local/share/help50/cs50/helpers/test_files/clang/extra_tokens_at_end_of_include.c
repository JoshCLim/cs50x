#include <stdio.h>c

int main(void) {

}
