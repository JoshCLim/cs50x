FILE_PATH = "(?:(?:.*)\/(?:[^/]+)\/)?"
BASH_PATH = "{}(?:ba)?sh".format(FILE_PATH)
