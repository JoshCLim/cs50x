int foo();

int main(void) {
  foo();
}

int foo() {}
