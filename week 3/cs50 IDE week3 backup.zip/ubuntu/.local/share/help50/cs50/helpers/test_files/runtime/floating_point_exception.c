int main(void) {
  int x = 1;
  int y = 0;
  x = x % y;
}
