#include <studio.h>

int main(void) {
  
}
