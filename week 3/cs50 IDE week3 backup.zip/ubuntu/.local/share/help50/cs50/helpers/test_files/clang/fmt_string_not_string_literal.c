#include <stdio.h>

int main(void) {
  char *c = "hi";
  int x;
  printf(c);
}
