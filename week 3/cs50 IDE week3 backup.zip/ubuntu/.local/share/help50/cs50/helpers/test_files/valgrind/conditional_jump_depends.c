int main(void) {
  int x;
  if (x == 17) {
    (void) x;
  }
}
