#include <stdio.h>

int main(void) {
  int x;
  printf("%d\n", x);
}
