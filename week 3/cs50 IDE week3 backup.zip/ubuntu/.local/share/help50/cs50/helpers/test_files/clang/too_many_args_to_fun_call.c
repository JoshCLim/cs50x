void f(void);

int main(void) {
  f(1);
}

void f(void) {
  int x;
  x++;
}
