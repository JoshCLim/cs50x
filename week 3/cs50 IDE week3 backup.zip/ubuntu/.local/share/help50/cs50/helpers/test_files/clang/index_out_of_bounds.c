int main(void) {
  int n = 2;
  int temp[n];
  for (int i = 0; i <= 2; i++) {
    temp[i] = 1;
  }
}
