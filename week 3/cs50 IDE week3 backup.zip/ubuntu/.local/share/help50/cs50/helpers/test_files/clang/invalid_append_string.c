#include <stdio.h>

int main(void) {
  char c = 'a';
  printf("%s" + c, "");
}
