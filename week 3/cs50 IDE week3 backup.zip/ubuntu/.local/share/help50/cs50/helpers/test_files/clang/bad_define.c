define _XOPEN_SOURCE 500
int main(void) {
}
