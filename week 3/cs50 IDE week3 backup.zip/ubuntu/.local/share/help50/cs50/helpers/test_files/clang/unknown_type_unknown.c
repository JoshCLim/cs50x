bar baz;
int main(void) {
}
